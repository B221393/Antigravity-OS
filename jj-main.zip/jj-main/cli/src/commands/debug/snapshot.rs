// Copyright 2024 The Jujutsu Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// TODO: Delete in jj 0.45.0+

use std::fmt::Debug;

use crate::cli_util::CommandHelper;
use crate::command_error::CommandError;
use crate::ui::Ui;

/// [DEPRECATED] Trigger a snapshot in the op log
///
/// This command is deprecated; use `jj util snapshot` instead.
#[derive(clap::Args, Clone, Debug)]
#[command(hide = true)]
pub struct DebugSnapshotArgs {}

pub async fn cmd_debug_snapshot(
    ui: &mut Ui,
    command: &CommandHelper,
    _args: &DebugSnapshotArgs,
) -> Result<(), CommandError> {
    writeln!(
        ui.warning_default(),
        "`jj debug snapshot` is deprecated; use `jj util snapshot` instead"
    )?;
    // workspace helper will snapshot as needed
    command.workspace_helper(ui)?;
    Ok(())
}
