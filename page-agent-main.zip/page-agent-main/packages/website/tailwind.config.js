export default {
	important: '#root',
}
